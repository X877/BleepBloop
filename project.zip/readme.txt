# bleepbloop

Author:
Blake Peden z3375913
Darwin Vickers z5018493
Justin Hung z3463243
Nicholas Yuwono z5016198
Scott Smith z3467847

***
live @ [darwinvickers.github.io/bleepbloop](https://darwinvickers.github.io/bleepbloop)

gh-pages is the web-facing branch

***

Bleep Bloop is a simple, intuitive music production tool.
This tool will allow you to collaborate in real-time over the internet to create different  
musical sounds, beats and styles by mixing-and-matching different sounds and instruments.

***

Web navigation

Start menu 
 |   |
 |   ----> Random Tune -> Enter username -> Main music editor
 |	
 |------->Private Tune -> Enter access code and username -> Main music editor with designated access code